from PyProject import  Module_1

Module_1.extract_pdf_by_coordinates()